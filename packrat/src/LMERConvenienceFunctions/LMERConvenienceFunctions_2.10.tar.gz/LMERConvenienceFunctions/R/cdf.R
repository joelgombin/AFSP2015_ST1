cdf <-
function(dir){setwd(paste(getwd(),"/",f()[dir],sep=""));as.matrix(list.files())}

