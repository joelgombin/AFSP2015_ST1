f <-
function(path=".",pattern=NULL,all.files=FALSE,full.names=FALSE,recursive=FALSE,ignore.case=FALSE)as.matrix(list.files(path=path,pattern=pattern,all.files=all.files,full.names=full.names,recursive=recursive,ignore.case=ignore.case))

