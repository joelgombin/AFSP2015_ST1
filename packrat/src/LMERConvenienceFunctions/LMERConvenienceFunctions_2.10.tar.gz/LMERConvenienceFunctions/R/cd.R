cd <-
function(dir)setwd(paste(getwd(),"/",f()[dir],sep=""))

