cn <-
function(data.frame)as.matrix(colnames(data.frame))

